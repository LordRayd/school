package afd;

/**
 * (NE PAS MODIFIER)
 * Exception soulevée en cas d'erreur dans la spécification ou le fonctionnement d'un AFD
 *
 */public class AFDException extends Exception {

  public AFDException(String s) {
    super(s);
  }

}
