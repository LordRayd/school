class A{
	private :
		float value;
	public :
		A(double a);
		A(const A & a);
		~A();
};
