#include "IntegerItem.h"

using namespace rpg;

int IntegerItem::getValue(){
    return 0;
}

int IntegerItem::getMaxValue(){
    return 0;
}

int IntegerItem::getMinValue(){
    return 0;
}
