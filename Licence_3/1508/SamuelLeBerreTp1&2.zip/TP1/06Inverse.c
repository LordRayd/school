#include <stdio.h>

int main(int argc, char * argv[]){
	float val;
	float val2;
	scanf("%f", &val);
	val2 = 1/val;
	printf("%f",val2);
	return 0;
}
