#include <stdio.h>

int main(int argc, char * argv[]){
	printf("%d",argc-1);
	return 0;
}
