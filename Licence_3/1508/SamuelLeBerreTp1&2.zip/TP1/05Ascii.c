#include <stdio.h>

int main(int argc, char * argv[]){
	int val;
	scanf("%c", &val);
	printf("%d",val);
	return 0;
}
