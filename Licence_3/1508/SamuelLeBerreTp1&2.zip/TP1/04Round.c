#include <stdio.h>

int main(int argc, char * argv[]){
	float val;
	scanf("%f", &val);
	printf("%.2f",val);
	return 0;
}
