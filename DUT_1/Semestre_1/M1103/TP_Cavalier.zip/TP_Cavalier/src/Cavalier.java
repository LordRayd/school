/**
  * Cette classe met en oeuvre l&acute;algorithme par essai/erreur r&eacute;cursif du d&eacute;placement d&acute;un cavalier sur un &eacute;chiquier. A partir d&acute;une case de
  * d&eacute;part, si un chemin pour parcourir toutes les cases une seule fois est trouv&eacute; alors l&acute;&eacute;chiquier est affich&eacute; avec le parcours complet du cavalier.
  * @author S.LEBERRE - Decembre 2016
  * @version 1.0
  * @since JDK 1.8
  */
  public class Cavalier {
	
	// variables globales
		/** La taille de l&acute;&eacute;chiquier en constante */
		final int TAILLE_ECHEC = 10;
		/** L&acute;&eacute;chiquier qui permet de visualiser les d&eacute;placements du cavalier */
		int[][] damier;
		/** Le nombre de coups jou&eacute;s qui permet de num&eacute;roter chaque d&eacute;placement et de savoir si le jeu est termin&eacute; */
		int numCoup;
	
	
	/**
	  * Point d&acute;entr&eacute;e de l&acute;&eacute;x&eacute;cution
	  */
	void principal() {
		
		// appel du lanceur
		lanceur();
	}
	
	/** Fait
	  * Test de la m&eacute;thode afficherDamier()
	  */ 
	void testAfficherDamier(){
		
		System.out.println("=========================== Test de la methode afficherDamier ===============================");


		// Test les cas d'erreurs
		System.out.println("\n--------- Test tous les cas d'erreurs");
			
			// tableau null
			damier = null;
			afficherDamier();
			
		// Test les cas normaux
		System.out.println("\n--------- Test les cas normaux");
			
			//définition du damier
			damier = new int [TAILLE_ECHEC][TAILLE_ECHEC];
			for(int i=0; i<TAILLE_ECHEC; i++){
				for(int j=0; j<TAILLE_ECHEC; j++){
					damier[i][j]=0;
				}
			}

			// test
			afficherDamier();
	}
	
	
	/**
	  * Test de la m&eacute;thode estCeValide()
	  */
	void testEstCeValide(){
		
	}
	
	/**
	  * Test de la m&eacute;thode donnerSuivants()
	  */
	void testDonnerSuivants(){
		
	}
	
	/**
	  * Lanceur de l&acute;application : cr&eacute;e le damier &agrave; la bonne taille et positionne le cavalier sur une premi&egrave;re case en X et en Y. Le compteur est
	  * initialis&eacute; &agrave; 1. On v&eacute;rifiera que les coordonn&eacute;es de la premi&egrave;re case sont valides. La coordonn&eacute;e (0, 0) correspond au coin sup&eacute;rieur
	  * gauche du damier. Ensuite, appeler une premi&egrave;re fois "essayer(...)". Suite au r&eacute;sultat renvoy&eacute; par "essayer(...)", soit le damier est
	  * affich&eacute; car le chemin est trouv&eacute;, soit il n&acute;y a pas de solution possible.
	  */
	void lanceur(){
		
		// appel des cas de test un par un
		testAfficherDamier();
		//testEstCeValide();
		//testDonnerSuivants();
	}
	
	/**
	  * A partir des cordonn&eacute;es (posX, posY), cette m&eacute;thode remplit le tableau "candidats" des 8 d&eacute;placements possibles du cavalier. Elle ne v&eacute;rifie 
	  * pas que les 8 d&eacute;placements sont valides. Cette v&eacute;rification est r&eacute;alis&eacute;e par la m&eacute;thode "estCeValide(...)". Les d&eacute;placements
	  * sont m&eacute;moris&eacute;s dans un tableau &agrave; 2 entr&eacute;es de taille 8 lignes X 2 colonnes. A chaque ligne correspond 1 position, sur le damier,
	  * possible (parmi 8) du cavalier apr&egrave;s son d&eacute;placement. Une position est repr&eacute;sent&eacute;e par le couple de coordonn&eacute;es (posX, posY).
	  * @param posX la position du cavalier en X (horizontale)
	  * @param posY la position du cavalier en Y (verticale)
	  * @param candidats tableau (8 lignes X 2 colonnes) qui m&eacute;morisent les 8 d&eacute;placements possibles du cavalier
	  */
	void donnerSuivants(int posX, int posY, int[][] candidats) {
		
	}
	
	/**
	  * M&eacute;thode qui renvoie vrai si la nouvelle coordonn&eacute;e (ou nouveau d&eacute;placement) du cavalier est possible.
	  * Le d&eacute;placement est possible si : la nouvelle coordonn&eacute;e ne sort pas du damier
	  * et la nouvelle case (newX, newY) n&acute;a pas encore &eacute;t&eacute; visit&eacute;e
	  * @param newX la nouvelle coordonn&eacute;e en X
	  * @param newY la nouvelle coordonn&eacute;e en Y
	  * @return vrai si la nouvelle coordonn&eacute;e (newX, newY) est valide
	  */
	boolean estCeValide(int newX, int newY) {
		boolean ret = false;
		
		return ret;
	}
	
	/**
	  * A partir des coordonn&eacute;es (posX, posY) du cavalier, calculer les 8 d&eacute;placements suivants possibles par appel de la m&eacute;thode &laquo;
	  * donnerSuivants(...) &raquo;. Ensuite, examiner les 8 d&eacute;placements possibles (newXi, newYi) un par un :
	  * V&eacute;rifier la validit&eacute; de la coordonn&eacute;e (newX, newY) &agrave; l&acute;aide de la m&eacute;thode &laquo; estCeValide(...) &raquo;.
	  * Si la coordonn&eacute;e est valide, inscrire le num&eacute;ro du coup jou&eacute; dans la case de coordonn&eacute;e (newX, newY) du tableau &laquo; damier &raquo; et
	  * incr&eacute;menter le nombre de coups.
	  * Si le nombre de coups == TAILLE_ECHEC X TAILLE_ECHEC alors la solution est trouv&eacute;e et renvoyer vrai (fin de la r&eacute;cursivit&eacute;).
	  * Sinon, &agrave; partir de cette nouvelle case valide (newX, newY), appeler &agrave; nouveau &laquo; essayer (...) &raquo; (appel r&eacute;cursif).
	  * Si ce nouvel appel de &laquo; essayer (...) &raquo; renvoie vrai, la solution finale est trouv&eacute;e.
	  * Sinon, revenir "en arri&egrave;re" en &eacute;crivant z&eacute;ro dans la case aux coordonn&eacute;es (newX, newY) du damier en d&eacute;cr&eacute;mentant le nombre
	  * de coups puis examiner la case suivante parmi les 8 d&eacute;placements possibles.
	  * @param posX la position du cavalier en X (horizontale)
	  * @param posY la position du cavalier en Y (verticale)
	  * @return vrai si le chemin des d&eacute;placements est trouv&eacute;
	  */
	boolean essayer(int posX, int posY){
		boolean ret = false;
		
		return ret;
	}
	
	/** Fait
	  * Affiche le damier &agrave; l&acute;&eacute;cran. Le coin sup&eacute;rieur gauche correspond aux coordonn&eacute;es (0, 0). L&acute;affichage consistera simplement &agrave;
	  * imprimer &agrave; l&acute;&eacute;cran TAILLE_ECHEC lignes de TAILLE_ECHEC entiers, chaque entier &eacute;tant le num&eacute;ro du coup jou&eacute;. Chaque
	  * d&eacute;placement du cavalier sur le damier incr&eacute;mente de un le num&eacute;ro du coup qui commence &agrave; la valeur 1 jusqu&acute;&agrave; TAILLE_ECHEC X
	  * TAILLE_ECHEC (lorsque le cavalier a termin&eacute; son parcours).
	  */
	void afficherDamier(){
		if(damier != null){
			int i = 0;
			int j;
			while (i < TAILLE_ECHEC ) {
				j = 0;
				while(j < TAILLE_ECHEC){
					System.out.print(damier[i][j] + "      ");
					j=j+1;
				}
				System.out.println("\n\n");
				i=i+1;
			}
		}else{
			System.out.println("Tableau null");
		}
	}
}
