﻿Le Tp Cavalier est fini
Le cavalier parcours le damier sans revenir sur une case déjà utilisé